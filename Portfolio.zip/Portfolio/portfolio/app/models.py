from django.db import models

category_choices = (
    ("Web", "Web Development"),
    ("Netwoking", "Networking"),
    ("Machine Leaning", "Machine Learning"),
    ("Arduino", "Arduino Projects"),
    ("Cyber Security", "Cyber Security")
)
class Project(models.Model):
    Img = models.ImageField(upload_to="Images", null=True)
    Title = models.CharField(max_length=255)
    Languages = models.CharField(max_length=255)
    Category = models.CharField(max_length=255, choices=category_choices)
    Date = models.DateField(null=True)
    file = models.FileField(null=True)

class Image(models.Model):
    profile_pic = models.ImageField(upload_to="Images", null=True)

# class Recieved_Emails(models.Model):
#     email_address = models.EmailField(null=True)
