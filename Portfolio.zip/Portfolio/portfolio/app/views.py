from datetime import datetime
from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponse
from django.template import loader
from . models import *
from .models import *

def home(request):
    projects = Project.objects.all()
    image = Image.objects.all()
    context ={
        "range" : range(6),
        "projects" : projects,
        "image" :image
    }
    template = loader.get_template("index.html")
    return HttpResponse(template.render(context, request))